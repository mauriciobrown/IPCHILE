// backend/controllers/eventoController.js

const db = require('../db');

exports.crearEvento = async (req, res) => {
    const { nombre, descripcion, fecha, ubicacion } = req.body;
    const usuario_id = req.user.id;
    try {
        await db.query('CALL crear_evento(?, ?, ?, ?, ?)', [nombre, descripcion, fecha, ubicacion, usuario_id]);
        res.status(201).send({ mensaje: 'Evento creado' }); // Código 201 para "Creado"
    } catch (error) {
        console.error('Error al crear evento:', error);
        res.status(500).send({ error: 'Error interno del servidor al crear evento' });
    }
};

exports.listarEventos = async (req, res) => {
    const usuario_id = req.user.id;
    try {
        const [rows] = await db.query('CALL listar_eventos_por_usuario(?)', [usuario_id]);
        res.send(rows[0]);
    } catch (error) {
        console.error('Error al listar eventos:', error);
        res.status(500).send({ error: 'Error interno del servidor al listar eventos' });
    }
};

// --- NUEVA FUNCIÓN: Obtener un evento por ID ---
exports.obtenerEventoPorId = async (req, res) => {
    const { id } = req.params; // El ID del evento viene de la URL
    const usuario_id = req.user.id; // El ID del usuario viene del token
    try {
        const [rows] = await db.query('CALL obtener_evento_por_id(?, ?)', [id, usuario_id]);
        const evento = rows[0][0]; // El procedimiento devuelve un array de arrays

        if (!evento) {
            return res.status(404).send({ error: 'Evento no encontrado o no autorizado' });
        }
        res.send(evento);
    } catch (error) {
        console.error(`Error al obtener evento con ID ${id}:`, error);
        res.status(500).send({ error: 'Error interno del servidor al obtener el evento' });
    }
};

// --- NUEVA FUNCIÓN: Actualizar un evento ---
exports.actualizarEvento = async (req, res) => {
    const { id } = req.params; // El ID del evento viene de la URL
    const { nombre, descripcion, fecha, ubicacion } = req.body; // Nuevos datos del evento
    const usuario_id = req.user.id; // El ID del usuario viene del token

    // Validación básica
    if (!nombre || !descripcion || !fecha || !ubicacion) {
        return res.status(400).send({ error: 'Todos los campos son requeridos para actualizar el evento.' });
    }

    try {
        const [result] = await db.query(
            'CALL actualizar_evento(?, ?, ?, ?, ?, ?)',
            [id, nombre, descripcion, fecha, ubicacion, usuario_id]
        );

        // MySQL no devuelve directamente el número de filas afectadas para CALL,
        // pero podemos asumir éxito si no hay error.
        // Si necesitas confirmar que se actualizó 1 fila, podrías ajustar el SP
        // para devolverlo, o hacer un SELECT después del UPDATE en el SP.
        res.send({ mensaje: 'Evento actualizado exitosamente' });
    } catch (error) {
        console.error(`Error al actualizar evento con ID ${id}:`, error);
        res.status(500).send({ error: 'Error interno del servidor al actualizar el evento' });
    }
};


/// Función para eliminar un evento (refactorizada a async/await)
exports.eliminarEvento = async (req, res) => { // <--- CAMBIO: Ahora es una función 'async'
    const { id } = req.params;
    const userId = req.user.id; // Asumimos que req.user.id viene del middleware de autenticación

    console.log('Backend: Intentando eliminar evento con ID:', id);
    console.log('Backend: ID de usuario autenticado (req.user.id):', userId, 'Tipo:', typeof userId);

    try {
        // 1. **VERIFICAR PROPIEDAD DEL EVENTO (CRÍTICO PARA LA SEGURIDAD)**
        const [rows] = await db.query('SELECT usuario_id FROM eventos WHERE id = ?', [id]);

        console.log('Backend: Resultado de la consulta para usuario_id (evento encontrado?):', rows);

        if (rows.length === 0) {
            console.log(`Backend: Evento con ID ${id} no encontrado.`);
            return res.status(404).json({ message: 'Evento no encontrado.' });
        }

        const eventoUsuarioId = rows[0].usuario_id;
        const parsedUserId = parseInt(userId, 10); // Asegura que el ID de usuario es un número para comparar

        if (eventoUsuarioId !== parsedUserId) {
            console.log(`Backend: usuario_id de DB (${eventoUsuarioId}) no coincide con userId (${parsedUserId}). Acceso denegado.`);
            return res.status(403).json({ message: 'No tienes permiso para eliminar este evento.' });
        }

        // 2. **LLAMAR AL PROCEDIMIENTO ALMACENADO**
        console.log('Backend: Llamando al procedimiento almacenado eliminar_evento con ID:', id);
        // Ejecutamos el SP de eliminación.
        // Algunas librerías de MySQL para Node.js devuelven 'affectedRows' directamente en 'result'.
        // Para procedimientos almacenados, 'result' a menudo es un array de arrays/objetos.
        // La clave es que, si no hay error aquí, el SP se ejecutó.
        const [result] = await db.query('CALL eliminar_evento(?)', [id]);

        // --- CONSOLE.LOGS ADICIONALES PARA DEPURACIÓN EN EL SERVIDOR ---
        console.log('Backend: Resultado crudo del procedimiento almacenado eliminar_evento:', result);
        // Si tu SP eliminar_evento no devuelve un conjunto de resultados, 'result' podría ser un array vacío o similar.
        // En algunos drivers, 'affectedRows' puede estar en result.affectedRows o result[0].affectedRows.
        // Si tu SP devuelve un valor de éxito/fracaso, podrías necesitar leerlo desde 'result'.
        // Por ahora, asumimos que si no hay error, el SP hizo su trabajo.
        // --- FIN CONSOLE.LOGS ADICIONALES ---

        // IMPORTANTE: Enviar una respuesta al frontend para que sepa que la operación terminó.
        // Esto ayudará a que el frontend no se quede "colgado" o reintente la solicitud.
        res.status(200).json({ message: 'Evento eliminado exitosamente.' });

    } catch (error) {
        // Captura cualquier error que ocurra durante la consulta, la ejecución del SP o la lógica.
        console.error('Backend: Error en eliminarEvento:', error);
        res.status(500).json({ message: 'Error interno del servidor al eliminar el evento.' });
    }
};