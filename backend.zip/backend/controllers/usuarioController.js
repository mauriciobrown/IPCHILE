// backend/controllers/usuarioController.js

const db = require('../db');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

exports.registrar = async (req, res) => {
    // CAMBIADO: Recibimos 'contrasena' sin tilde del frontend
    const { nombre, correo, contrasena } = req.body; // <-- CAMBIADO: 'contrasena'
    const hashedPass = await bcrypt.hash(contrasena, 10); // <-- USADO: 'contrasena'
    // La base de datos espera 'contrasena' sin tilde
    await db.query('CALL registrar_usuario(?, ?, ?)', [nombre, correo, hashedPass]);
    res.send({ mensaje: 'Usuario registrado' });
};

exports.login = async (req, res) => {
    // CAMBIADO: Recibimos 'contrasena' sin tilde del frontend
    const { correo, contrasena } = req.body; // <-- CAMBIADO: 'contrasena'

    try {
        const [rows] = await db.query('CALL obtener_usuario_por_correo(?)', [correo]);
        const usuario = rows[0][0];

        if (!usuario) {
            return res.status(401).send({ error: 'Usuario no existe' });
        }

        // Comparamos la contraseña de entrada (contrasena) con la almacenada en DB (usuario.contrasena)
        const valido = await bcrypt.compare(contrasena, usuario.contrasena); // <-- USADO: 'contrasena'
        if (!valido) {
            return res.status(401).send({ error: 'Contraseña incorrecta' });
        }

        const token = jwt.sign({ id: usuario.id }, process.env.JWT_SECRET, { expiresIn: '1h' });
        res.send({ token });

    } catch (error) {
        console.error('Error durante el login:', error);
        res.status(500).send({ error: 'Error interno del servidor al iniciar sesión' });
    }
};