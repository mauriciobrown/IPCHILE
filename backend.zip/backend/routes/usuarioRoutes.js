const express = require('express');
const router = express.Router();

// Importa las funciones del controlador de usuario
// Asegúrate de que 'registrar' y 'login' estén entre las llaves
const { registrar, login } = require('../controllers/usuarioController'); // ¡Esta línea es crucial!

// Ruta para el registro de usuarios
// Aquí solo definimos '/registrar' porque en app.js ya le dimos el prefijo '/api/usuarios'
router.post('/registrar', registrar);

// Ruta para el inicio de sesión
// Aquí solo definimos '/login' porque en app.js ya le dimos el prefijo '/api/usuarios'
router.post('/login', login);

// Ruta de prueba para usuarios (opcional)
router.get('/', (req, res) => {
  res.send('Rutas de usuario funcionando');
});

module.exports = router;

