// backend/routes/eventoRoutes.js

const express = require('express');
const router = express.Router();
const { crearEvento, listarEventos, obtenerEventoPorId, actualizarEvento,eliminarEvento } = require('../controllers/eventoController'); // Importa las nuevas funciones
const auth = require('../middlewares/auth');

router.post('/', auth, crearEvento);
router.get('/', auth, listarEventos);

// --- NUEVAS RUTAS ---
router.get('/:id', auth, obtenerEventoPorId);     // Ruta para obtener un evento específico
router.put('/:id', auth, actualizarEvento);       // Ruta para actualizar un evento específico
router.delete('/:id', auth, eliminarEvento);     // <--- AÑADIDO: Ruta para eliminar un evento específico
// --- FIN NUEVAS RUTAS ---

module.exports = router;
